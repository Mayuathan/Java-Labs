package cst8284.shape;

public class Rectangle extends Square implements ShapeConstants {

	private double height;

	public Rectangle() {
		this(minValue, minValue);
	}

	public Rectangle(double width, double height) {
		super(width);
		this.setHeight(height);
	}

	public Rectangle(Rectangle rectangle) {
		this(rectangle.getWidth(), rectangle.getHeight());
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getArea() {
		return this.getWidth() * this.getHeight();
	}

	public double getPerimeter() {
		return 2 * (this.getWidth() + this.getHeight());
	}

	@Override
	public String toString() {
		return (" Rectangle extends " + super.toString());

	}

	public boolean equals(Object obj) {
		if (!(obj instanceof Rectangle))
			return false;
		Rectangle rectangle = (Rectangle) obj;
		return super.equals(obj) && this.getHeight() == rectangle.getHeight();
	}

}
