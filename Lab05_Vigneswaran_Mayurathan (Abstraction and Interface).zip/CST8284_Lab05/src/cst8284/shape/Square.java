package cst8284.shape;

public class Square extends BasicShape implements ShapeComparator, ShapeConstants, Comparable<BasicShape> {

	public Square() {
		this(minValue);
	}

	public Square(double width) {
		super(width);

	}

	public Square(Square square) {
		this(square.getWidth());

	}

	public double getArea() {
		return Math.pow(getWidth(), 2);
	}

	public double getPerimeter() {
		return 4 * getWidth();

	}

	@Override
	public String toString() {
		return (" Square extends " + super.toString());

	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Square)) {
			return false;
		}
		Square other = (Square) obj;
		return super.equals(obj) && this.getWidth() == other.getWidth();

	}

	@Override
	public boolean isIdentical(Object o) {
		if (!(o instanceof Square))
			return false;
		Square square = (Square) o;
		if (compareTo(square) == 0)
			return true;
		return false;
	}

	@Override
	public boolean isGreaterThan(Object o) {
		if (!(o instanceof Square))
			return false;
		Square square = (Square) o;
		if (compareTo(square) == 1)
			return true;
		return false;
	}

	@Override
	public boolean isSmallerThan(Object o) {
		if (!(o instanceof Square))
			return false;
		Square square = (Square) o;
		if (compareTo(square) == -1)
			return true;
		return false;
	}

	@Override
	public int compareTo(BasicShape bs) {
		double dif = this.getWidth() - bs.getWidth();
		return Math.abs(dif) == 0 ? 0 : Math.abs(dif) < 1 ? -1 : 1;
	}

}
