package cst8284.shape;

public class Circle extends BasicShape implements ShapeComparator, ShapeConstants, Comparable<BasicShape> {

	public Circle() {
		this(minValue);
	}

	public Circle(double width) {
		super(width);
	}

	public Circle(Circle circle) {
		this(circle.getWidth());
	}

	public double getArea() {
		return (Math.PI * ((Math.pow(getWidth(), 2) / 4)));

	}

	public double getPerimeter() {
		return (Math.PI * getWidth());

	}

	@Override
	public String toString() {
		return (" Circle extends " + super.toString());
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Circle)) {
			return false;
		}
		Circle other = (Circle) obj;
		return super.equals(obj) && (this.getWidth() == other.getWidth());

	}

	@Override
	public boolean isIdentical(Object o) {
		if (!(o instanceof Circle))
			return false;
		Circle circle = (Circle) o;
		if (compareTo(circle) == 0)
			return true;
		return false;
	}

	@Override
	public boolean isGreaterThan(Object o) {
		if (!(o instanceof Circle))
			return false;
		Circle circle = (Circle) o;
		if (compareTo(circle) == 1)
			return true;
		return false;
	}

	@Override
	public boolean isSmallerThan(Object o) {
		if (!(o instanceof Circle))
			return false;
		Circle circle = (Circle) o;
		if (compareTo(circle) == -1)
			return true;
		return false;
	}

	@Override
	public int compareTo(BasicShape bs) {
		double dif = this.getWidth() - bs.getWidth();
		return Math.abs(dif) == 0 ? 0 : Math.abs(dif) < 1 ? -1 : 1;
	}
}
