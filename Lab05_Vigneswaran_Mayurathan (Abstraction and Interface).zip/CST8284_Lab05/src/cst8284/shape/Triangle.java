package cst8284.shape;

public class Triangle extends BasicShape implements ShapeComparator, ShapeConstants, Comparable<BasicShape> {

	public Triangle() {
		this(minValue);

	}

	public Triangle(double width) {
		super(width);
	}

	public Triangle(Triangle triangle) {
		this(triangle.getWidth());

	}

	public double getArea() {
		return (Math.sqrt(3) * Math.pow(getWidth(), 2)) / 4;

	}

	public double getPerimeter() {
		return 3 * getWidth();

	}

	@Override
	public String toString() {
		return (" Triangle extends" + super.toString());

	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Triangle)) {
			return false;
		}
		Triangle other = (Triangle) obj;
		return super.equals(obj) && this.getWidth() == other.getWidth();

	}

	@Override
	public boolean isIdentical(Object o) {
		if (!(o instanceof Triangle))
			return false;
		Triangle triangle = (Triangle) o;
		if (compareTo(triangle) == 0)
			return true;
		return false;
	}

	@Override
	public boolean isGreaterThan(Object o) {
		if (!(o instanceof Triangle))
			return false;
		Triangle triangle = (Triangle) o;
		if (compareTo(triangle) == 1)
			return true;
		return false;
	}

	@Override
	public boolean isSmallerThan(Object o) {
		if (!(o instanceof Triangle))
			return false;
		Triangle triangle = (Triangle) o;
		if (compareTo(triangle) == -1)
			return true;
		return false;
	}

	@Override
	public int compareTo(BasicShape bs) {
		double dif = this.getWidth() - bs.getWidth();
		return Math.abs(dif) == 0 ? 0 : Math.abs(dif) < 1 ? -1 : 1;
	}

}