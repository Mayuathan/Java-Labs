package cst8284.shape.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import cst8284.shape.Circle;
import cst8284.shape.Square;
import cst8284.shape.Triangle;

public class TestBasicShape {

	@Test
	public void testPerimeterCircle() {
		Circle c1 = new Circle(3.0);
		assertTrue(c1.getPerimeter() == 3.0 * Math.PI);
	}

	@Test
	public void testAreaCircle() {
		Circle c1 = new Circle(3.0);
		assertTrue(c1.getArea() == Math.PI * ((Math.pow(3, 2) / 4)));
	}

	@Test
	public void testPerimeterSquare() {
		Square s1 = new Square(3.0);
		assertTrue(s1.getPerimeter() == 3.0 * 4);
	}

	@Test
	public void testAreaSquare() {
		Square s1 = new Square(3.0);
		assertTrue(s1.getArea() == Math.pow(3, 2));
	}

	@Test
	public void testPerimeterTriangle() {
		Triangle t1 = new Triangle(3.0);
		assertTrue(t1.getPerimeter() == 3.0 * 3);
	}

	@Test
	public void testAreaTriangle() {
		Triangle t1 = new Triangle(3.0);
		assertTrue(t1.getArea() == Math.sqrt(3) * Math.pow(3.0, 2) / 4);
	}
}
