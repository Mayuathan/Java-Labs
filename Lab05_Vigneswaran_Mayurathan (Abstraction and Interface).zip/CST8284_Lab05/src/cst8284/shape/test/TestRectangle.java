package cst8284.shape.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import cst8284.shape.Rectangle;
import cst8284.shape.Square;

public class TestRectangle {

	@Test
	public void testWithEqualWidthAndHeightPerimeter() {
		Rectangle r = new Rectangle(2.0, 2.0);
		Square s = new Square(2.0);
		assertEquals(r.getPerimeter(), s.getPerimeter(), 1e-12);
	}

	@Test
	public void testWithEqualWidthAndHeightArea() {
		Rectangle r = new Rectangle();
		Square s = new Square();
		assertEquals(r.getArea(), s.getArea(), 1e-12);
	}

}
