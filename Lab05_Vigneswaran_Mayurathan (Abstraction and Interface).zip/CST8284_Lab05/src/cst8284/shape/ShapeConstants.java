package cst8284.shape;

interface ShapeConstants {

	public double minValue = 1.0;
	public double maxValue = 10000.0;
}
