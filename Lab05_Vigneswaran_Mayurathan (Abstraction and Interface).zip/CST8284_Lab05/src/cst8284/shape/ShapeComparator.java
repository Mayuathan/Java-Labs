package cst8284.shape;

interface ShapeComparator {
	public boolean isIdentical(Object o);

	public boolean isGreaterThan(Object o);

	public boolean isSmallerThan(Object o);

}
