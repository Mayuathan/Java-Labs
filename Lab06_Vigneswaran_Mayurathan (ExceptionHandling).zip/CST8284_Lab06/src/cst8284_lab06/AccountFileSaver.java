package cst8284_lab06;

import java.io.*;
import java.util.Scanner;

public class AccountFileSaver {
	private Account act;
	String fileName;
	private static Scanner in = new Scanner(System.in);
	private Scanner input;

	AccountFileSaver(String fn) {
		this.fileName = fn;
	}

	public boolean saveAccount() throws Exception {

		// TODO5: Add all the remaining code to open a file
		// and write the account details in a file
		// The format of the account to save should be a line like this:
		// FirstName,LastName,AccountNumber,StartDate
		// John,Winston,156-5555555,Wed Jan 23 00:00:00 EST 2019
		// You must catch the IOException and throw a
		// BadFileException with message : Error Writing To File
		// The exception must be caught by the calling method in
		// AccountLauncher class

		try {
			File save = new File(fileName);
			PrintWriter print = new PrintWriter(save);
			print.write(getAccount().getFirstName() + "," + getAccount().getLastName() + ","
					+ getAccount().getAccountNumber() + ",");
			print.close();

		} catch (IOException ex) {
			throw new Exception("Error Writing To File");
		}
		return true;

	}

	public boolean createAccount() {
		boolean accountLoaded = false;
		try {
			System.out.println("Input Account Details.");
			String firstName = getResponseTo("First name: ");
			String lastName = getResponseTo("Last name: ");
			String actNum = getResponseTo("Account number (using format NNN-NNNNNNN): ");
			String actStartUpDate = getResponseTo("Account startup date as YYYY-MM-DD: ");
			setAccount(new Account(actNum, firstName, lastName, actStartUpDate));
			accountLoaded = true;
		} catch (BadAccountInputException be) {
			System.out.println(be.getMessage() + ". Please re-enter account details \n");
		} catch (Exception ex) {
			System.out.println("General exception thrown. source unknown");
		}
		return accountLoaded;
	}

	private String getResponseTo(String s) {
		System.out.print(s);
		return (in.nextLine());
	}

	public boolean readAccount() throws Exception {
		// TODO6: Add all the remaining code to open a file
		// and read all the lines in a file
		// Use StringBuffer to read the content of the file
		// and output the content on the standard output
		// You must catch FileNotFoundException and return if the file does not exist
		// BadFileException with message : "File does not exist"
		// Return true only if there is no error.

		StringBuffer sb = new StringBuffer();

		try {
			File Input = new File(fileName);
			input = new Scanner(Input);

			while (input.hasNext()) {
				sb.append(input.next());
			}
			System.out.println(sb.toString());

			return true;
		} catch (FileNotFoundException fe) {
			throw new Exception("File does not exist");
		}
	}

	public boolean cleanAccountFile() {
		try {
			File f = new File(fileName);
			if (f.delete()) {
				return true;
			} else {
				return false;
			}
		}

		catch (Exception e) {
			System.out.println(" Error while reading file : " + e.getMessage());
			return false;
		}
	}

	public Account getAccount() {
		return act;
	}

	public void setAccount(Account act) {
		this.act = act;
	}

}
