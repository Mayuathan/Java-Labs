package cst8284_lab06;

public class BadAccountInputException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BadAccountInputException() {
		this("Bad input: value entered is incorrect");
	}

	public BadAccountInputException(String message) {
		super(message);
	}

}
