package cst8284.junit.lab4.test;

import java.math.BigDecimal;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import cst8284.junit.lab4.BadCurrencyException;
import cst8284.junit.lab4.Currency;
import cst8284.junit.lab4.Money;


public class MoneyTest {

    private static final BigDecimal PRICE = new BigDecimal("47");
    private Currency currency, anotherCurrency;
    private Money money;
	private static final BigDecimal DIFFERENT_PRICE = new BigDecimal("1337");

    @Before
    public void initMoney() throws Exception {
        currency = new Currency("USD");
        money = new Money(PRICE, currency);
        
        anotherCurrency = new Currency("CAD");;
    }

    @Test
    public void testGetPrice_True() {
    	 assertTrue(money.getPrice().intValue()==47);
    }
    
    @Test
    public void testGetPrice_False() {
       assertFalse(money.getPrice().intValue()==48);
    }

    @Test
    public void testGetCurrency_True() {
    	assertTrue(money.getCurrency().equals(currency));
    }

    @Test
    public void testGetCurrency_False() {
    		assertFalse(money.getCurrency().equals(anotherCurrency));
    }
    
    @Test
    public void testEquals_WhenEquals() {
        Money secondMoney = new Money(PRICE, currency);

        assertTrue(money.equals(secondMoney));
    }

    @Test
    public void testEquals_WhenNotEquals() {
    	// Create another money object 
    	// Verify that the hash code for money is different
    	// from the hash code of this new object
    	Money anotherMoney = new Money(DIFFERENT_PRICE, currency);
    	assertNotEquals(money.hashCode(),anotherMoney.hashCode());
    }

    @Test
    public void testHashCode_Equal() {
    	// Create a money object  with a different currency
    	// Verify that the hash code for money is different
    	// from the hash code of this new object
    	Money anotherMoney = new Money(PRICE, anotherCurrency);
    	assertNotEquals(money.hashCode(),anotherMoney.hashCode());
    }
    
    @Test
    public void testHashCode_NotEqual() {
    	Money anotherMoney = new Money(PRICE, anotherCurrency);
    	assertTrue(money.hashCode()!= anotherMoney.hashCode());
    }
}
