package cst8284.junit.lab4.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import cst8284.junit.lab4.Counter;

public class CounterTest {
	
	private Counter c1;
	private Counter c2;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		c1 = new Counter(5);
		c2 = new Counter(3);
	}

	@After
	public void tearDown() throws Exception {
		c1 = null;
		c2 = null;
	}

	@Test
	public void testCounter() {
		assertNotNull(c1);
	}

	@Test
	public void testCounterInt() {
		assertTrue(c1.getCount()==5);
	}

	@Test
	public void testIncrement() {
		c1.increment();
		assertTrue(c1.getCount()==6);
	}

	@Test
	public void testDecrement() {
		c1.decrement();
		assertTrue(c1.getCount()==4);
	}

	@Test
	public void testGetCount() {
		c2 = new Counter(6);
		assertTrue(c2.getCount()== 6);
	}

	@Test
	public void testAdd() {
		Counter result = new Counter();
		assertTrue((result.add(c1, c2)).getCount()==8);
	}

	@Test
	public void testSub() {
		Counter result = new Counter();
		assertTrue((result.sub(c1, c2)).getCount()==2);
	}

	@Test
	public void testToString() {
		assertTrue(c1.toString().equals("Count is 5"));
	}

}
