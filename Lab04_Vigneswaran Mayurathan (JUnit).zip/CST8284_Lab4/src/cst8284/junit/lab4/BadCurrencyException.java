package cst8284.junit.lab4;


public class BadCurrencyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    
}
