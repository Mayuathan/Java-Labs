package cst8284.lab7.generic;

public class ZonedDateTime {

	public int compareTo(ZonedDateTime startTime) {
		return 0;
	}

}
