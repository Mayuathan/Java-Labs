package cst8284.lab7.generic;

public class ApplicationLauncher {
	public static void main(String[] args) {

	}
}