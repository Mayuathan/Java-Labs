package cst8284.calculator;

public class ComplexCalculator {

	private java.util.Scanner op = new java.util.Scanner(System.in);
	private Complex c; // stores result of current calculation

	public ComplexCalculator(Complex c1, Complex c2) {

		System.out.println("Which math operation do you wish to perform?  Enter +, -, *, /");

		switch (op.nextLine().charAt(0)) {
		case '+':
			setComplexResult(add(c1, c2));
			break;
		case '-':
			setComplexResult(subtract(c1, c2));
			break;

		case '*':
			setComplexResult(multiply(c1, c2));
			break;

		case '/':
			setComplexResult(divide(c1, c2));
			break;

		default:
			System.out.println("Unknown operation requested");
		}
	}

	public ComplexCalculator() {
	} // Needed for Lab 4; do not change

	public Complex add(Complex c1, Complex c2) {
		double real = c1.getReal() + c2.getReal(); // As per the Lab Appendix
		double imag = c1.getImag() + c2.getImag();
		return (new Complex(real, imag));
	}

	public Complex subtract(Complex c1, Complex c2) {
		double real = c1.getReal() - c2.getReal();
		double imag = c1.getImag() - c2.getImag();
		return (new Complex(real, imag));
	}

	public Complex multiply(Complex c1, Complex c2) {
		double real = (c1.getReal() * c2.getReal()) - (c1.getImag() * c2.getImag());
		double imag = (c1.getReal() * c2.getImag()) + (c2.getReal() * c1.getImag());
		return (new Complex(real, imag));
	}

	public Complex divide(Complex c1, Complex c2) {
		if (multiply(c2, c2.Conjugate()).isZero()) {
			System.out.println("Divid-by-zero error detected");
			return new Complex(0, 0);
		}
		Complex numerator = multiply(c1, c2.Conjugate());
		double denominator = multiply(c2, c2.Conjugate()).getReal();
		return new Complex(numerator.getReal() / denominator, numerator.getImag() / denominator);

	}

	public void setComplexResult(Complex c) {
		this.c = c;
	}

	public Complex getComplexResult() {

		return c;
	}

	public String toString() {
		return c.toString();

	}

}
